"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tl = require("azure-pipelines-task-lib/task");
var Util_1 = require("./Util");
var ServiceBus;
(function (ServiceBus) {
    function sendServiceInfo() {
        var request = require('request');
        var dict = parseConnectionString(tl.loc("connectionString"));
        var data = JSON.stringify(getMessage());
        var token = createSharedAccessToken(dict["Endpoint"] + "servicetreequeue", dict["SharedAccessKeyName"], dict["SharedAccessKey"]);
        var options = {
            url: dict["Endpoint"] + 'servicetreequeue/messages',
            body: data,
            timeout: 5000,
            headers: {
                'Content-Type': 'application/atom+xml;type=entry;charset=utf-8',
                'Authorization': token
            }
        };
        console.log("Send service data to Chronicle");
        request.post(options, function (err, res, body) {
            if (err) {
                tl.debug(err);
                return;
            }
            tl.debug("Servicebus sent status: " + res.statusCode);
        });
    }
    ServiceBus.sendServiceInfo = sendServiceInfo;
    function getMessage() {
        var instanceUrl = tl.getVariable("System.TeamFoundationCollectionUri");
        var project = tl.getVariable("System.TeamProject");
        var service = tl.getInput("Service", false);
        var messageBody = Util_1.Util.isNullEmptyOrUndefined(tl.getVariable("Release.ReleaseId"))
            ? {
                Type: "Build",
                Service: service,
                Id: tl.getVariable("Build.BuildId"),
                Definition: tl.getVariable("System.DefinitionId"),
                Project: project,
                InstanceUrl: instanceUrl
            }
            : {
                Type: "Release",
                Service: service,
                Id: tl.getVariable("Release.ReleaseId"),
                Definition: tl.getVariable("Release.DefinitionId"),
                Deployment: tl.getVariable("Release.DeploymentID"),
                Environment: tl.getVariable("Release.EnvironmentId"),
                Project: project,
                InstanceUrl: instanceUrl
            };
        return messageBody;
    }
    function parseConnectionString(connectionString) {
        var dictionary = {};
        var parts = connectionString.split(';');
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i];
            var index = p.indexOf('=');
            var key = p.substring(0, index);
            var value = p.substring(index + 1);
            value = value.replace("sb:", 'https:');
            dictionary[key] = value;
        }
        return dictionary;
    }
    function createSharedAccessToken(uri, saName, saKey) {
        var utf8 = require('utf8');
        var crypto = require('crypto');
        var encoded = encodeURIComponent(uri);
        var now = new Date();
        var week = 60 * 60 * 24 * 7;
        var ttl = Math.round(now.getTime() / 1000) + week;
        var signature = encoded + '\n' + ttl;
        var signatureUTF8 = utf8.encode(signature);
        var hash = crypto.createHmac('sha256', saKey).update(signatureUTF8).digest('base64');
        return 'SharedAccessSignature sr=' + encoded + '&sig=' +
            encodeURIComponent(hash) + '&se=' + ttl + '&skn=' + saName;
    }
})(ServiceBus = exports.ServiceBus || (exports.ServiceBus = {}));
