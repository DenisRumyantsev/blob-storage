"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tl = require("azure-pipelines-task-lib/task");
var request = require("request");
var Products;
(function (Products) {
    var apiHost = tl.getVariable("apiHost");
    var definitionId = tl.getVariable("System.DefinitionId");
    var organization = tl.getVariable("System.CollectionId");
    var project = tl.getVariable("System.TeamProjectId");
    var repository = tl.getVariable("Build.Repository.ID");
    var loginHost = "https://login.microsoftonline.com/microsoft.com/oauth2/token";
    function Backfill(productId) {
        var options = {
            url: loginHost,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            form: {
                client_id: tl.getVariable("client_id"),
                resource: tl.getVariable("resource"),
                grant_type: 'client_credentials',
                client_secret: tl.getVariable("client_secret")
            }
        };
        return request.post(options, function (err, res, body) {
            if (err) {
                tl.debug("token error => " + err);
                return;
            }
            tl.debug("token res => " + res.statusCode);
            if (res.statusCode === 200) {
                console.log("Backfill products catalog");
                var obj = JSON.parse(body);
                CheckAndAddRepository(productId, obj.access_token);
                CheckAndAddDefinition(productId, obj.access_token);
            }
        });
    }
    Products.Backfill = Backfill;
    function CheckAndAddRepository(productId, token) {
        var requestUrl = apiHost + "/products/" + productId + "/artifacts?artifactType=Scms.Git.Vsts";
        var options = {
            url: requestUrl,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            timeout: 5000,
        };
        request(options, function (err, res, body) {
            if (err) {
                tl.debug("product catalog repository get error => " + err);
                return;
            }
            tl.debug("product catalog repository get result: " + res.statusCode);
            if (res.statusCode === 200) {
                var artifactId = "vsts://" + organization + "/" + project + "/" + repository;
                var artifacts = [];
                JSON.parse(body).value.forEach(function (element) {
                    artifacts.push({
                        artifactId: element.artifactId,
                        artifactType: element.artifactType
                    });
                });
                if (!artifacts.some(function (e) { return e.artifactId === artifactId; })) {
                    return AddRepository(artifacts, artifactId);
                }
                else {
                    tl.debug("Repository exist in product catalog");
                }
            }
        });
        function AddRepository(artifacts, artifactId) {
            artifacts.push({
                artifactId: artifactId,
                artifactType: "Scms.Git.Vsts"
            });
            var options = {
                url: requestUrl,
                headers: {
                    'Content-Type': 'application/json-patch+json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify(artifacts)
            };
            return request.put(options, function (err, res, body) {
                if (err) {
                    tl.debug("product catalog add repository failed: " + err);
                    return;
                }
                tl.debug("product catalog add repository result: " + res.statusCode);
            });
        }
    }
    function CheckAndAddDefinition(productId, token) {
        var requestUrl = apiHost + "/products/" + productId + "/artifacts?artifactType=Microsoft.AzureDevOps/BuildDefinition";
        var options = {
            url: requestUrl,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            timeout: 5000,
        };
        request(options, function (err, res, body) {
            if (err) {
                tl.debug("product catalog definitions get error => " + err);
                return;
            }
            tl.debug("product catalog definitions get result: " + res.statusCode);
            if (res.statusCode === 200) {
                var artifacts = JSON.parse(body).value;
                var artifactId = "vsts://" + organization + "/" + project + "/" + definitionId;
                if (!artifacts.some(function (e) { return e.artifactId === artifactId; })) {
                    return AddDefinition(artifactId);
                }
                else {
                    tl.debug("Definition exist in product catalog");
                }
            }
        });
        function AddDefinition(artifactId) {
            var json = JSON.stringify({
                artifactId: artifactId,
                artifactType: "Microsoft.AzureDevOps/BuildDefinition"
            });
            requestUrl = requestUrl + ("&artifactId=" + artifactId);
            var options = {
                url: requestUrl,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: json
            };
            return request.put(options, function (err, res, body) {
                if (err) {
                    tl.debug("product catalog add definition failed: " + err);
                    return;
                }
                tl.debug("product catalog add definition result: " + res.statusCode);
            });
        }
    }
})(Products = exports.Products || (exports.Products = {}));
