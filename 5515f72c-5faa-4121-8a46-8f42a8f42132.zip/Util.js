"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Util;
(function (Util) {
    function isNullEmptyOrUndefined(obj) {
        return obj === null || obj === '' || obj === undefined;
    }
    Util.isNullEmptyOrUndefined = isNullEmptyOrUndefined;
})(Util = exports.Util || (exports.Util = {}));
