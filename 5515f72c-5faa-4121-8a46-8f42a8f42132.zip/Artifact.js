"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Artifact = /** @class */ (function () {
    function Artifact() {
    }
    return Artifact;
}());
exports.Artifact = Artifact;
