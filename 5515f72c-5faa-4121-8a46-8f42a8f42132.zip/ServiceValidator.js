"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tl = require("azure-pipelines-task-lib/task");
var path = require("path");
var ServiceBus_1 = require("./ServiceBus");
var Util_1 = require("./Util");
var Products_1 = require("./Products");
var pattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
tl.setResourcePath(path.join(__dirname, "task.json"));
var defId = tl.getVariable("system.definitionId");
var notRequiredList = tl.getVariable("ServiceTreeLinkNotRequiredIds");
var gw = tl.getInput("ServiceTreeGateway", false);
var service = tl.getInput("Service", false);
var usage = tl.getInput("BuildOutputUsage", false);
var required = Util_1.Util.isNullEmptyOrUndefined(notRequiredList) || notRequiredList.split(",").indexOf(defId) === -1;
if (required && (Util_1.Util.isNullEmptyOrUndefined(gw) || Util_1.Util.isNullEmptyOrUndefined(service))) {
    tl.setResult(tl.TaskResult.Failed, "ServiceTree service has not been selected");
}
else if (!Util_1.Util.isNullEmptyOrUndefined(service) && !pattern.test(service)) {
    tl.setResult(tl.TaskResult.Failed, "Invalid value set as ServiceTree service id");
}
else {
    tl.setVariable("SERVICETREE_SERVICE_ID", service);
    tl.setVariable("SERVICETREE_BUILD_OUTPUT_USAGE", usage);
    console.log("Definition id: " + defId);
    console.log("BuildOutputUsage: " + usage);
    console.log("Service: " + service);
    //send info to servicebus
    ServiceBus_1.ServiceBus.sendServiceInfo();
    //products backfill
    if (!Util_1.Util.isNullEmptyOrUndefined(tl.getVariable("apiHost")) && Util_1.Util.isNullEmptyOrUndefined(tl.getVariable("Release.ReleaseId"))) {
        Products_1.Products.Backfill(service);
    }
}
